@extends('layouts.master')
@section('content')
<div class="container">
Dashboard
</div>
@endsection
