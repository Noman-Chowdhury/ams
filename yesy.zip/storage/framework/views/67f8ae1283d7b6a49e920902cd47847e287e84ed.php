<?php $__env->startSection('content'); ?>
<div class="container">
Dashboard
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/noman/Music/ams/resources/views/home.blade.php ENDPATH**/ ?>