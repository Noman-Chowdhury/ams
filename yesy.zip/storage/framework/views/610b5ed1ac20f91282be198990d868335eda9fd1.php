<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6" href="#">AMS</a>
    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary" type="submit">Sign out</button>
            </form>
        </div>
    </div>
</header>
<?php /**PATH /home/noman/Music/ams/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>