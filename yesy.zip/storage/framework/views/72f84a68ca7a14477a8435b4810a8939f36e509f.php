<?php $__env->startSection('content'); ?>

    <h3 class="text-center"><?php echo e(\Illuminate\Support\Carbon::parse(\request()->date)->format('Y-m-d')); ?></h3>
    <?php if(auth()->user()->attendances()->whereDate('date', \Illuminate\Support\Carbon::parse(\request()->date)->format('Y-m-d'))->first()): ?>
        <p class="text-success">
            You were Present
        </p>
    <?php else: ?>
        <p class="text-danger">
            You were Absent
        </p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/noman/Music/ams/resources/views/member/attendance/log.blade.php ENDPATH**/ ?>