<?php $__env->startSection('content'); ?>
    <h3>User : <?php echo e($user->name); ?></h3>
    <form action="<?php echo e(route('users.update', encrypt($user->id))); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-4">
                <label>
                    Name
                </label>
                <input name="name" class="form-control" type="text" value="<?php echo e(old('name', $user->name)); ?>">
            </div>
            <div class="col-4">
                <label>
                    Email
                </label>
                <input name="email" class="form-control" type="email" value="<?php echo e(old('email', $user->email)); ?>">
            </div>
            <div class="col-4">
                <label>
                    Role
                </label>
                <select name="role" id="" class="form-control">
                    <option value="admin" <?php echo e($user->role === 'admin'? 'selected':''); ?>>Admin</option>
                    <option value="member" <?php echo e($user->role === 'member'? 'selected':''); ?>>Member</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <label>
                    Current Profile Picture:
                </label>
                <?php if(!$user->avatar): ?>
                    No Picture Found
                <?php else: ?>
                <img
                    src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url('user/avatar/'.$user->avatar)); ?>"
                    alt="<?php echo e($user->name); ?>" style="width: 100px; height: 100px; border-radius: 5%">
                <?php endif; ?>
            </div>
            <div class="col-12">
                <label for="">Change Picture</label>
                <input type="file" accept="image/*" name="avatar">
            </div>
        </div>
        <button type="submit">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/noman/Music/ams/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>