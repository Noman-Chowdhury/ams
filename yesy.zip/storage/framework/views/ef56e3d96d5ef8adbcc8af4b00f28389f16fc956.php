<?php $__env->startSection('content'); ?>
    <div class="row mt-2">
        <div class="col-4">
            <div class="card text-bg-success mb-3" style="max-width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e(\App\Models\User::where('role','admin')->count().' Admin'); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card text-bg-success mb-3" style="max-width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e(\App\Models\User::where('role','member')->count().' Member'); ?></h5>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/noman/Music/ams/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>